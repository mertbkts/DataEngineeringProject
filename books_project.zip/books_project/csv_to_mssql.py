# from airflow import DAG
# from airflow.operators.python_operator import PythonOperator
# import pandas as pd
# from sqlalchemy import create_engine


# def load_csv_to_mssql():
#     csv_file_path ='/Users/sarbartursunova/Documents/DataEngineering/books_project/updated_data_new.csv'
#     df= pd.read_csv(csv_file_path)

#     #  MSSQL Connection Details
#     db_username= 'root'
#     db_password= 'root'
#     db_host= '5432'
#     db_name='test_db'

#     # create SQLALchemy engine for MSSQL

#     engine= create_engine(f"mssql+pyodbc://{db_username}:{db_password}@{db_host}/{db_name}?driver=ODBC+Driver+17+for+SQL+Server")

#     # load data into mssql table
#     table_name = 'fact_publications'
#     df.to_sql(table_name, con=engine, if_exists='replace',index=False)

#     # define airflow DAG
#     default_args={
#         'owner':'airflow',
#         'depends_on_past': False,
#         'start_date': datetime(2023,12,25),
#         'retries':1,
#                   }
    
#     dag = DAG('csv_to_mssql_dag',
#               default_args=default_args,
#               description='Load CSV data into MSSQL',
#               schedule_interval=None,
#               )
#     load_csv_task = PythonOperator(
#         task_id='load_csv_to_mssql_task',
#         python_callable=load_csv_to_mssql,
#         dag=dag,
#     )

#     # set task dependencies
#     load_csv_task



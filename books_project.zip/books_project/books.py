import psycopg2
import time
from datetime import datetime

